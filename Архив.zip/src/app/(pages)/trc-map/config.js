export const metaData = {
    title: "Карта ТРЦ",
    description: "Карта ТРЦ",
    keywords: "Новости и мероприятия"
};

export const breadCrumbsLevels = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Карта ТРЦ',
        levelLink: '',
    },
]
