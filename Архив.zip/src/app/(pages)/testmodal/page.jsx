'use client';

import {NewsSubscribeModal} from "../../../shared/ui/news-subscribe";
import {UISection} from "../../../shared/ui/section";
export default function TestModal() {






    return (
        <UISection>
            <NewsSubscribeModal></NewsSubscribeModal>

        </UISection>
    );
}
