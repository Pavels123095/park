export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Арендаторам',
        levelLink: '',
    },
];
