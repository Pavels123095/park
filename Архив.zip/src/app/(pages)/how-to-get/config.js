export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Как добраться',
        levelLink: '',
    },
];

export const META_DATA = {
    title: 'Как добраться',
    description: 'Как добраться',
    keywords: 'Как добраться',
};
