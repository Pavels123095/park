export const metaData = {
    title: "Новости и мероприятия",
    description: "Новости и мероприятия",
    keywords: "Новости и мероприятия"
};

export const breadCrumbsLevels = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Новости и мероприятия',
        levelLink: '',
    },
]
