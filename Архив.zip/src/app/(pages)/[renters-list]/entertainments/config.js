export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Развлечения',
        levelLink: '',
    },
]

export const META_DATA = {
    title: "Развлечения",
    description: "Развлечения",
    keywords: "Развлечения"
};
