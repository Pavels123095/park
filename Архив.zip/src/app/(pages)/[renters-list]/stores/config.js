export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Магазины',
        levelLink: '',
    },
];

export const META_DATA = {
    title: "Магазины",
    description: "Магазины",
    keywords: "Магазины"
};
