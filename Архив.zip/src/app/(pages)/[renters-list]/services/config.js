export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Услуги и сервис',
        levelLink: '',
    },
];

export const META_DATA = {
    title: "Услуги и сервис",
    description: "Услуги и сервис",
    keywords: "Услуги и сервис"
};
