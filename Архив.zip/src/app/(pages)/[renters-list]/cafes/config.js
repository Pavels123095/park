export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Кафе и рестораны',
        levelLink: '',
    },
]

export const META_DATA = {
    title: "Кафе и рестораны",
    description: "Кафе и рестораны",
    keywords: "Кафе и рестораны"
};
