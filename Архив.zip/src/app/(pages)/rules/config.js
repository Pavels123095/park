export const BREAD_CRUMBS_LEVELS = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Правила ТРЦ',
        levelLink: '',
    },
];
