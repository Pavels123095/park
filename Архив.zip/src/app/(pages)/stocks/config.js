export const metaData = {
    title: "Акции и скидки",
    description: "Акции и скидки",
    keywords: "Акции и скидки"
};

export const breadCrumbsLevels = [
    {
        levelName: 'Главная',
        levelLink: '/',
    },
    {
        levelName: 'Акции и скидки',
        levelLink: '',
    },
]
