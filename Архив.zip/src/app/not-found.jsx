import PageNotFound from "../widgets/page-not-found/ux";

export default function NotFound() {
    return (
        <PageNotFound />
    )
}
