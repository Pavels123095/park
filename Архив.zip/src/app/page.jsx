import HomePage from "./(pages)/home/page";

export const metadata = {
  title: "ТРЦ Пушкино Парк",
  description: "ТРЦ Пушкино Парк",
  keywords: "ТРЦ Пушкино Парк"
};

export default function IndexPage() {
  return (
    <HomePage />
  );
}
