'use client';

export default function Error() {
    return (
        <div>Ошибка рендеринга компонента</div>
    )
}
