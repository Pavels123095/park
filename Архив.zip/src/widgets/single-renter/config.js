export const RENTERS_BREAD_CRUMBS = {
    stores: {
        levelName: 'Магазины',
        levelLink: '/stores',
    },
    cafes: {
        levelName: 'Кафе и рестораны',
        levelLink: '/cafes',
    },
    entertainments: {
        levelName: 'Развлечения',
        levelLink: '/entertainments',
    },
    services: {
        levelName: 'Услуги',
        levelLink: '/services',
    },
}
