export const LINKS = [
    {
        id: 'l01',
        anchor: 'Магазины',
        href: '/stores',
    },
    {
        id: 'l02',
        anchor: 'Кафе и рестораны',
        href: '/cafes',
    },
    {
        id: 'l03',
        anchor: 'Развлечения',
        href: '/entertainments',
    },
    {
        id: 'l04',
        anchor: 'Услуги и сервис',
        href: '/services',
    },
    {
        id: 'l05',
        anchor: 'Театр III Р.И.М.',
        href: 'https://t-rim.ru/',
    },
    {
        id: 'l06',
        anchor: 'Флик фляк',
        href: 'https://flik-flyak.ru/',
    },
]
