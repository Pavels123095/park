export const ALLOWED_FILES_TO_ADD = [
    'jpg', 'jpeg', 'gif', 'png' ,'bmp',
    'mkv', 'mp4', 'm4v', 'flv', 'avi',
    'wmv', 'mp3', 'm4a', 'wav', 'zip',
    'alz', 'egg', 'zar', 'hwp', 'gul',
    'doc', 'docx', 'xls', 'xlsx', 'ppt',
    'pptx', 'pdf', 'rtf', 'hwpx', 'txt'
];

export const ALLOWED_SIZE_FILE = 10485761;
