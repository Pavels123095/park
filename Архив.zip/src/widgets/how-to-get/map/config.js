export const MAP_POINT_PUSHKINO_PARK = [56.017849, 37.885656];

export const MAP_CONFIG = {
    center: [56.017849, 37.885656],
    zoom: 15,
    controls: [],
};
