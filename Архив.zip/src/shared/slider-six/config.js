export const DEFAULT_DATA = [
    {
        id: '01',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '02',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '03',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '04',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '05',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '06',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '07',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '08',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '09',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '10',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'

    },
    {
        id: '11',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
    {
        id: '12',
        link: '#!',
        image: '/images/temp_dev/main-page/retailer-park/retailer.jpg',
        alt: '',
        heading: 'Заголовок'
    },
]
