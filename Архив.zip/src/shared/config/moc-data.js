export const rentersSingleTileMocData = [
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    },
    {
        "id": 2,
        "idSpace": "131",
        "liter": "Б",
        "logo": "/images/temp_dev/renters/renter.jpg",
        "alt": "Бренд Zolla принадлежит Factor LLC и является крупнейшей торговой сетью, которую развивает компания.",
        "heading": "Zolla",
        "category": [
            {
                category: 'Женская одежда'
            }
        ],
        "floor": 1,
        "link": "http://ppark.dev.grapheme.ru/api/tenants/2",
        "stocks": [
            {
                "id": 1,
                "stockType": null,
                "backgroundButton": null
            }
        ],
        "new": true,
        "has_stocks": true
    }
]
