export const TYPES_SIMILAR_RENTERS = {
    stores: {
        heading: 'Похожие магазины',
    },
    cafes: {
        heading: 'Похожие кафе и рестораны',
    },
    entertainments: {
        heading: 'Похожие развлечения',
    },
    services: {
        heading: 'Похожие услуги',
    },
}
