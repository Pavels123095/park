export const OTHER_STOCKS_SLIDES_LONG = [
    {
        id: '01',
        link: '#!',
        image: '/images/temp_dev/single-renter/main-banner.jpg',
        heading: 'Заголовок',
        description: 'Описание',
    },
    {
        id: '02',
        link: '#!',
        image: '/images/temp_dev/single-renter/main-banner.jpg',
        heading: 'Заголовок',
        description: 'Описание',
    },
    {
        id: '03',
        link: '#!',
        image: '/images/temp_dev/single-renter/main-banner.jpg',
        heading: 'Заголовок',
        description: 'Описание',
    },
    {
        id: '04',
        link: '#!',
        image: '/images/temp_dev/single-renter/main-banner.jpg',
        heading: 'Заголовок',
        description: 'Описание',
    },
    {
        id: '05',
        link: '#!',
        image: '/images/temp_dev/single-renter/main-banner.jpg',
        heading: 'Заголовок',
        description: 'Описание',
    },
    {
        id: '06',
        link: '#!',
        image: '/images/temp_dev/single-renter/main-banner.jpg',
        heading: 'Заголовок',
        description: 'Описание',
    },
]
