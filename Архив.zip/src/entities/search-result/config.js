export const SEARCH_CATEGORIES = {
    'news': 'Новости',
    'events': 'Мероприятия',
    'stocks': 'Акции',
    'info': 'Информация',
}
