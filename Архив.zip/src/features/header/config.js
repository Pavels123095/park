export const KEYS_TO_LOCAL_SEARCH = {
    'акции': [
        {
            heading: "Акции",
            link: "/stocks",
        }
    ],
    'магазины': [
        {
            heading: "Магазины",
            link: "/stores",
        }
    ],
    'кафе и рестораны': [
        {
            heading: "Кафе и рестораны",
            link: "/cafes",
        }
    ],
    'кафе': [
        {
            heading: "Кафе и рестораны",
            link: "/cafes",
        }
    ],
    'ресторан': [
        {
            heading: "Кафе и рестораны",
            link: "/cafes",
        }
    ],
    'рестораны': [
        {
            heading: "Кафе и рестораны",
            link: "/cafes",
        }
    ],
    'услуги и сервисы': [
        {
            heading: "Услуги и сервисы",
            link: "/services",
        }
    ],
    'услуги': [
        {
            heading: "Услуги и сервисы",
            link: "/services",
        }
    ],
    'сервис': [
        {
            heading: "Услуги и сервисы",
            link: "/services",
        }
    ],
    'сервисы': [
        {
            heading: "Услуги и сервисы",
            link: "/services",
        }
    ],
    'развлечения': [
        {
            heading: "Развлечения",
            link: "/entertainments",
        }
    ],
    'новости и мероприятия': [
        {
            heading: "Новости и мероприятия",
            link: "/news-and-events",
        }
    ],
    'новости': [
        {
            heading: "Новости и мероприятия",
            link: "/news-and-events",
        }
    ],
    'мероприятия': [
        {
            heading: "Новости и мероприятия",
            link: "/news-and-events",
        }
    ],
    'вакансии': [
        {
            heading: "Вакансии",
            link: "/vacancies",
        }
    ],
    'работа': [
        {
            heading: "Вакансии",
            link: "/vacancies",
        }
    ],
}
